﻿/*
=========================================================
01 - CONFIGURACION DE CARPETAS DE RESPALDO
Base de datos: GimnasioDB
Entorno: SQL Server 2025 en Docker (Linux)
=========================================================

IMPORTANTE:
SQL Server no crea estas carpetas mediante BACKUP DATABASE.
Primero se deben crear desde PowerShell en Windows.

Contenedor conocido: sqlserver-2025
Volumen Docker montado en: /backup

Ejecutar en PowerShell:

docker exec -u 0 sqlserver-2025 mkdir -p /backup/GimnasioDB/FULL
docker exec -u 0 sqlserver-2025 mkdir -p /backup/GimnasioDB/DIFF
docker exec -u 0 sqlserver-2025 mkdir -p /backup/GimnasioDB/LOG
docker exec -u 0 sqlserver-2025 chown -R mssql:mssql /backup/GimnasioDB

La estructura esperada dentro del contenedor es:

/backup/
  GimnasioDB/
    FULL/
    DIFF/
    LOG/

En Windows, el volumen /backup es un volumen Docker independiente.
No se debe asumir que corresponde a C:\sqlserver2025\shared\backup.

Este archivo es documentación ejecutable en SSMS solo para verificar
que SQL Server identifica la base de datos y su modelo de recuperación.
*/

USE master;
GO

SELECT
    name AS BaseDatos,
    recovery_model_desc AS ModeloRecuperacion,
    state_desc AS Estado
FROM sys.databases
WHERE name = N'GimnasioDB';
GO

/*
Si no aparecen las tres carpetas después de ejecutar los comandos
de PowerShell, no continúe con los respaldos.
*/
