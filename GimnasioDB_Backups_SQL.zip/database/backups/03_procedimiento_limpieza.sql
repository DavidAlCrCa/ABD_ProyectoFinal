﻿/*
=========================================================
03 - PROCEDIMIENTO DE LIMPIEZA DE RESPALDOS
Base de datos: GimnasioDB
=========================================================

Retención acordada:
  FULL: 30 días
  DIFF: 7 días
  LOG : 14 días

Los respaldos se guardan en carpetas separadas para que la
limpieza de un tipo no afecte a los otros.

IMPORTANTE:
- La limpieza de archivos usa xp_delete_file.
- Ejecutar primero con @Ejecutar = 0 para revisar el alcance.
- Cambiar a @Ejecutar = 1 únicamente después de comprobar rutas,
  permisos y política de retención.
- Conservar al menos un FULL reciente y sus diferenciales/logs
  requeridos para el periodo de recuperación.
- No borrar manualmente archivos mientras haya una restauración
  en curso.
*/

USE GimnasioDB;
GO

CREATE OR ALTER PROCEDURE dbo.usp_LimpiarRespaldos
    @Ejecutar BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RutaFull NVARCHAR(4000) = N'/backup/GimnasioDB/FULL';
    DECLARE @RutaDiff NVARCHAR(4000) = N'/backup/GimnasioDB/DIFF';
    DECLARE @RutaLog  NVARCHAR(4000) = N'/backup/GimnasioDB/LOG';

    DECLARE @FechaFull DATETIME = DATEADD(DAY, -30, GETDATE());
    DECLARE @FechaDiff DATETIME = DATEADD(DAY, -7, GETDATE());
    DECLARE @FechaLog  DATETIME = DATEADD(DAY, -14, GETDATE());

    SELECT
        @FechaFull AS LimiteFULL,
        @FechaDiff AS LimiteDIFF,
        @FechaLog AS LimiteLOG,
        @Ejecutar AS EjecutarEliminacion;

    IF @Ejecutar = 0
    BEGIN
        PRINT N'MODO DE SIMULACION: no se eliminó ningún archivo.';
        PRINT N'FULL: se evaluarían archivos anteriores a 30 días.';
        PRINT N'DIFF: se evaluarían archivos anteriores a 7 días.';
        PRINT N'LOG: se evaluarían archivos anteriores a 14 días.';
        RETURN;
    END;

    /*
      xp_delete_file es el procedimiento extendido utilizado por
      tareas de mantenimiento de SQL Server. Si el entorno Linux
      no lo admite o no tiene permisos sobre /backup, la ejecución
      fallará sin continuar silenciosamente.
    */

    EXEC master.dbo.xp_delete_file
        0, @RutaFull, N'bak', @FechaFull, 0;

    EXEC master.dbo.xp_delete_file
        0, @RutaDiff, N'bak', @FechaDiff, 0;

    EXEC master.dbo.xp_delete_file
        0, @RutaLog, N'trn', @FechaLog, 0;

    PRINT N'Proceso de limpieza ejecutado.';
END;
GO

/*
Primera ejecución recomendada: solo simulación.
*/
EXEC dbo.usp_LimpiarRespaldos @Ejecutar = 0;
GO

/*
Después de validar que xp_delete_file funciona en el contenedor
y que las rutas son correctas, el Job puede invocarlo con @Ejecutar=1.
No habilite la eliminación automática hasta probar la restauración.
*/
