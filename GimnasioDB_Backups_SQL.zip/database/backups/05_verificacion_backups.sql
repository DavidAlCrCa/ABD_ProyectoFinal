﻿/*
=========================================================
05 - VERIFICACION DE RESPALDOS Y JOBS
Base de datos: GimnasioDB
=========================================================
*/

USE master;
GO

-- 1. Estado y modelo de recuperación.
SELECT
    name AS BaseDatos,
    state_desc AS Estado,
    recovery_model_desc AS ModeloRecuperacion
FROM sys.databases
WHERE name = N'GimnasioDB';
GO

-- 2. Historial de respaldos de GimnasioDB.
SELECT
    bs.backup_start_date AS Inicio,
    bs.backup_finish_date AS Finalizacion,
    CASE bs.type
        WHEN 'D' THEN 'FULL'
        WHEN 'I' THEN 'DIFFERENTIAL'
        WHEN 'L' THEN 'LOG'
        ELSE bs.type
    END AS TipoRespaldo,
    bs.backup_size / 1024.0 / 1024.0 AS TamanoMB,
    bs.is_copy_only AS CopyOnly,
    mf.physical_device_name AS RutaArchivo
FROM msdb.dbo.backupset AS bs
INNER JOIN msdb.dbo.backupmediafamily AS mf
    ON bs.media_set_id = mf.media_set_id
WHERE bs.database_name = N'GimnasioDB'
ORDER BY bs.backup_finish_date DESC;
GO

-- 3. Jobs asociados a GimnasioDB.
SELECT
    j.name AS Job,
    j.enabled AS Habilitado,
    s.name AS Programacion
FROM msdb.dbo.sysjobs AS j
LEFT JOIN msdb.dbo.sysjobschedules AS js
    ON j.job_id = js.job_id
LEFT JOIN msdb.dbo.sysschedules AS s
    ON js.schedule_id = s.schedule_id
WHERE j.name LIKE N'GimnasioDB%'
ORDER BY j.name;
GO

-- 4. Último resultado de ejecución de cada Job.
SELECT
    j.name AS Job,
    h.run_date,
    h.run_time,
    h.run_duration,
    h.run_status,
    CASE h.run_status
        WHEN 0 THEN 'Fallo'
        WHEN 1 THEN 'Correcto'
        WHEN 2 THEN 'Reintento'
        WHEN 3 THEN 'Cancelado'
        WHEN 4 THEN 'En progreso'
        ELSE 'Sin historial'
    END AS Resultado
FROM msdb.dbo.sysjobs AS j
OUTER APPLY (
    SELECT TOP (1) *
    FROM msdb.dbo.sysjobhistory AS x
    WHERE x.job_id = j.job_id
      AND x.step_id = 0
    ORDER BY x.instance_id DESC
) AS h
WHERE j.name LIKE N'GimnasioDB%'
ORDER BY j.name;
GO

-- 5. Archivos físicos de la base de datos.
SELECT
    name AS NombreLogico,
    type_desc AS TipoArchivo,
    physical_name AS RutaFisica,
    size * 8.0 / 1024 AS TamanoMB
FROM GimnasioDB.sys.database_files;
GO
