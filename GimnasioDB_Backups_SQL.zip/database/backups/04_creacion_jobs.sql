﻿/*
=========================================================
04 - CREACION DE JOBS Y PROGRAMACIONES
Base de datos: GimnasioDB
SQL Server Agent
=========================================================

Programación:
  FULL: cada domingo a las 01:00
  DIFF: todos los días a las 02:00
  LOG : cada hora, al minuto 15
  LIMPIEZA: domingo a las 03:00 (modo simulación inicialmente)

Requisito:
SQL Server Agent debe estar instalado y en ejecución.
En SQL Server Linux, verificar que SQL Server Agent esté habilitado.
*/

USE msdb;
GO

IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = N'GimnasioDB')
    THROW 52001, 'No existe GimnasioDB.', 1;
GO

/*-------------------------------------------------------
  JOB 1: RESPALDO FULL SEMANAL
-------------------------------------------------------*/
IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'GimnasioDB - FULL semanal')
    EXEC msdb.dbo.sp_delete_job @job_name = N'GimnasioDB - FULL semanal', @delete_unused_schedule = 1;
GO

EXEC msdb.dbo.sp_add_job
    @job_name = N'GimnasioDB - FULL semanal',
    @enabled = 1,
    @description = N'Respaldo FULL semanal de GimnasioDB.';
GO

EXEC msdb.dbo.sp_add_jobstep
    @job_name = N'GimnasioDB - FULL semanal',
    @step_name = N'Crear respaldo FULL',
    @subsystem = N'TSQL',
    @database_name = N'master',
    @command = N'
DECLARE @Archivo NVARCHAR(4000);
DECLARE @Fecha CHAR(8) = CONVERT(CHAR(8), GETDATE(), 112);
DECLARE @Hora CHAR(6) = REPLACE(CONVERT(CHAR(8), GETDATE(), 108), '':'', '''');

SET @Archivo = N''/backup/GimnasioDB/FULL/GimnasioDB_FULL_'' + @Fecha + N''_'' + @Hora + N''.bak'';

BACKUP DATABASE GimnasioDB
TO DISK = @Archivo
WITH INIT, COMPRESSION, CHECKSUM, STATS = 10;
',
    @on_success_action = 1,
    @on_fail_action = 2;
GO

EXEC msdb.dbo.sp_add_schedule
    @schedule_name = N'GimnasioDB - Domingo 0100',
    @enabled = 1,
    @freq_type = 8,
    @freq_interval = 1,
    @freq_recurrence_factor = 1,
    @active_start_time = 010000;
GO

EXEC msdb.dbo.sp_attach_schedule
    @job_name = N'GimnasioDB - FULL semanal',
    @schedule_name = N'GimnasioDB - Domingo 0100';
GO

EXEC msdb.dbo.sp_add_jobserver
    @job_name = N'GimnasioDB - FULL semanal';
GO


/*-------------------------------------------------------
  JOB 2: RESPALDO DIFFERENTIAL DIARIO
-------------------------------------------------------*/
IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'GimnasioDB - DIFF diario')
    EXEC msdb.dbo.sp_delete_job @job_name = N'GimnasioDB - DIFF diario', @delete_unused_schedule = 1;
GO

EXEC msdb.dbo.sp_add_job
    @job_name = N'GimnasioDB - DIFF diario',
    @enabled = 1,
    @description = N'Respaldo diferencial diario de GimnasioDB.';
GO

EXEC msdb.dbo.sp_add_jobstep
    @job_name = N'GimnasioDB - DIFF diario',
    @step_name = N'Crear respaldo DIFF',
    @subsystem = N'TSQL',
    @database_name = N'master',
    @command = N'
DECLARE @Archivo NVARCHAR(4000);
DECLARE @Fecha CHAR(8) = CONVERT(CHAR(8), GETDATE(), 112);
DECLARE @Hora CHAR(6) = REPLACE(CONVERT(CHAR(8), GETDATE(), 108), '':'', '''');

IF (SELECT recovery_model_desc FROM sys.databases WHERE name = N''GimnasioDB'') <> N''FULL''
    THROW 52002, ''GimnasioDB no está en modelo FULL.'', 1;

SET @Archivo = N''/backup/GimnasioDB/DIFF/GimnasioDB_DIFF_'' + @Fecha + N''_'' + @Hora + N''.bak'';

BACKUP DATABASE GimnasioDB
TO DISK = @Archivo
WITH DIFFERENTIAL, INIT, COMPRESSION, CHECKSUM, STATS = 10;
',
    @on_success_action = 1,
    @on_fail_action = 2;
GO

EXEC msdb.dbo.sp_add_schedule
    @schedule_name = N'GimnasioDB - Diario 0200',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @active_start_time = 020000;
GO

EXEC msdb.dbo.sp_attach_schedule
    @job_name = N'GimnasioDB - DIFF diario',
    @schedule_name = N'GimnasioDB - Diario 0200';
GO

EXEC msdb.dbo.sp_add_jobserver
    @job_name = N'GimnasioDB - DIFF diario';
GO


/*-------------------------------------------------------
  JOB 3: RESPALDO LOG CADA HORA
-------------------------------------------------------*/
IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'GimnasioDB - LOG cada hora')
    EXEC msdb.dbo.sp_delete_job @job_name = N'GimnasioDB - LOG cada hora', @delete_unused_schedule = 1;
GO

EXEC msdb.dbo.sp_add_job
    @job_name = N'GimnasioDB - LOG cada hora',
    @enabled = 1,
    @description = N'Respaldo del log de transacciones cada hora.';
GO

EXEC msdb.dbo.sp_add_jobstep
    @job_name = N'GimnasioDB - LOG cada hora',
    @step_name = N'Crear respaldo LOG',
    @subsystem = N'TSQL',
    @database_name = N'master',
    @command = N'
DECLARE @Archivo NVARCHAR(4000);
DECLARE @Fecha CHAR(8) = CONVERT(CHAR(8), GETDATE(), 112);
DECLARE @Hora CHAR(6) = REPLACE(CONVERT(CHAR(8), GETDATE(), 108), '':'', '''');

IF (SELECT recovery_model_desc FROM sys.databases WHERE name = N''GimnasioDB'') <> N''FULL''
    THROW 52003, ''GimnasioDB no está en modelo FULL.'', 1;

SET @Archivo = N''/backup/GimnasioDB/LOG/GimnasioDB_LOG_'' + @Fecha + N''_'' + @Hora + N''.trn'';

BACKUP LOG GimnasioDB
TO DISK = @Archivo
WITH INIT, COMPRESSION, CHECKSUM, STATS = 10;
',
    @on_success_action = 1,
    @on_fail_action = 2;
GO

EXEC msdb.dbo.sp_add_schedule
    @schedule_name = N'GimnasioDB - Cada hora minuto 15',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 8,
    @freq_subday_interval = 1,
    @active_start_time = 001500;
GO

EXEC msdb.dbo.sp_attach_schedule
    @job_name = N'GimnasioDB - LOG cada hora',
    @schedule_name = N'GimnasioDB - Cada hora minuto 15';
GO

EXEC msdb.dbo.sp_add_jobserver
    @job_name = N'GimnasioDB - LOG cada hora';
GO


/*-------------------------------------------------------
  JOB 4: LIMPIEZA CONSERVADORA
-------------------------------------------------------*/
IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'GimnasioDB - Limpieza respaldos')
    EXEC msdb.dbo.sp_delete_job @job_name = N'GimnasioDB - Limpieza respaldos', @delete_unused_schedule = 1;
GO

EXEC msdb.dbo.sp_add_job
    @job_name = N'GimnasioDB - Limpieza respaldos',
    @enabled = 1,
    @description = N'Limpieza de respaldos según retención. Inicialmente en modo simulación.';
GO

EXEC msdb.dbo.sp_add_jobstep
    @job_name = N'GimnasioDB - Limpieza respaldos',
    @step_name = N'Evaluar archivos antiguos',
    @subsystem = N'TSQL',
    @database_name = N'GimnasioDB',
    @command = N'EXEC dbo.usp_LimpiarRespaldos @Ejecutar = 0;',
    @on_success_action = 1,
    @on_fail_action = 2;
GO

EXEC msdb.dbo.sp_add_schedule
    @schedule_name = N'GimnasioDB - Limpieza domingo 0300',
    @enabled = 1,
    @freq_type = 8,
    @freq_interval = 1,
    @freq_recurrence_factor = 1,
    @active_start_time = 030000;
GO

EXEC msdb.dbo.sp_attach_schedule
    @job_name = N'GimnasioDB - Limpieza respaldos',
    @schedule_name = N'GimnasioDB - Limpieza domingo 0300';
GO

EXEC msdb.dbo.sp_add_jobserver
    @job_name = N'GimnasioDB - Limpieza respaldos';
GO

PRINT N'Jobs y programaciones creados.';
GO
