﻿USE master;
GO

SELECT
    name AS BaseDatos,
    recovery_model_desc AS ModeloRecuperacion,
    state_desc AS Estado
FROM sys.databases
WHERE name = N'GimnasioDB';
GO

