﻿USE master;
GO

IF DB_ID(N'GimnasioDB') IS NULL
    THROW 53001, 'No existe GimnasioDB.', 1;

IF DB_ID(N'GimnasioDB_RestauracionPrueba') IS NOT NULL
    THROW 53002, 'La base de prueba ya existe. Revise o elimine manualmente la prueba anterior antes de continuar.', 1;
GO

DECLARE @BackupFile NVARCHAR(4000);
DECLARE @SQL NVARCHAR(MAX);
DECLARE @Move NVARCHAR(MAX) = N'';
DECLARE @DataPath NVARCHAR(4000) = N'/var/opt/mssql/data/';

-- Obtener el último FULL y su archivo.
SELECT TOP (1)
    @BackupFile = mf.physical_device_name
FROM msdb.dbo.backupset AS bs
INNER JOIN msdb.dbo.backupmediafamily AS mf
    ON bs.media_set_id = mf.media_set_id
WHERE bs.database_name = N'GimnasioDB'
  AND bs.type = 'D'
  AND bs.is_copy_only = 0
ORDER BY bs.backup_finish_date DESC;

IF @BackupFile IS NULL
    THROW 53003, 'No se encontró un respaldo FULL para restaurar.', 1;

-- Construir MOVE usando los nombres lógicos actuales de GimnasioDB.
SELECT
    @Move = @Move +
        CASE WHEN @Move = N'' THEN N'' ELSE N',' END +
        N' MOVE N''' + REPLACE(name, '''', '''''') +
        N''' TO N''' + @DataPath +
        N'GimnasioDB_RestauracionPrueba_' +
        CONVERT(NVARCHAR(10), file_id) +
        CASE type WHEN 1 THEN N'.ldf' ELSE N'.mdf' END +
        N''''
FROM GimnasioDB.sys.database_files
ORDER BY file_id;

SET @SQL =
    N'RESTORE DATABASE [GimnasioDB_RestauracionPrueba] ' +
    N'FROM DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N''' ' +
    N'WITH ' + @Move + N', RECOVERY, CHECKSUM, STATS = 10;';

PRINT N'Respaldo seleccionado: ' + @BackupFile;
PRINT @SQL;

EXEC sys.sp_executesql @SQL;
GO

-- Comprobar estado de la base restaurada.
SELECT
    name,
    state_desc,
    recovery_model_desc
FROM sys.databases
WHERE name = N'GimnasioDB_RestauracionPrueba';
GO

-- Comprobar integridad de la base restaurada.
DBCC CHECKDB (N'GimnasioDB_RestauracionPrueba')
WITH NO_INFOMSGS;
GO

