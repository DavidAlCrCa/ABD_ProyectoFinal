﻿USE GimnasioDB;
GO

CREATE OR ALTER PROCEDURE dbo.usp_LimpiarRespaldos
    @Ejecutar BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RutaFull NVARCHAR(4000) = N'/backup/GimnasioDB/FULL';
    DECLARE @RutaDiff NVARCHAR(4000) = N'/backup/GimnasioDB/DIFF';
    DECLARE @RutaLog  NVARCHAR(4000) = N'/backup/GimnasioDB/LOG';

    DECLARE @FechaFull DATETIME = DATEADD(DAY, -30, GETDATE());
    DECLARE @FechaDiff DATETIME = DATEADD(DAY, -7, GETDATE());
    DECLARE @FechaLog  DATETIME = DATEADD(DAY, -14, GETDATE());

    SELECT
        @FechaFull AS LimiteFULL,
        @FechaDiff AS LimiteDIFF,
        @FechaLog AS LimiteLOG,
        @Ejecutar AS EjecutarEliminacion;

    IF @Ejecutar = 0
    BEGIN
        PRINT N'MODO DE SIMULACION: no se eliminó ningún archivo.';
        PRINT N'FULL: se evaluarían archivos anteriores a 30 días.';
        PRINT N'DIFF: se evaluarían archivos anteriores a 7 días.';
        PRINT N'LOG: se evaluarían archivos anteriores a 14 días.';
        RETURN;
    END;


    EXEC master.dbo.xp_delete_file
        0, @RutaFull, N'bak', @FechaFull, 0;

    EXEC master.dbo.xp_delete_file
        0, @RutaDiff, N'bak', @FechaDiff, 0;

    EXEC master.dbo.xp_delete_file
        0, @RutaLog, N'trn', @FechaLog, 0;

    PRINT N'Proceso de limpieza ejecutado.';
END;
GO


EXEC dbo.usp_LimpiarRespaldos @Ejecutar = 0;
GO
